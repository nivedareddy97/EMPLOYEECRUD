package com.cap.anurag;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCrud1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
